<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsPricing2 extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-pricing-2';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Pricing 2', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'Pricing' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_Pricing2',
			[
				'label' => esc_html__( 'Pricing', 'bdevs-elementor' ),
			]	
		);		
		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Pricing Items block', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					]
				],
				'fields' => [
					[
						'name'    => 'image',
						'label'   => esc_html__( 'Background image', 'bdevs-elementor' ),
						'type'    => Controls_Manager::MEDIA,
						'dynamic' => [ 'active' => true ],
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
					],
					[
						'name'        => 'link',
						'label'       => esc_html__( 'Link', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'https://shtheme.com/demosd/perukar/?page_id=67' , 'bdevs-elementor' ),
						'label_block' => true,
					],	
					[
						'name'        => 'heading',
						'label'       => esc_html__( 'Heading', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Haircut' , 'bdevs-elementor' ),
						'label_block' => true,
					],	
					[
						'name'    => 'tabs2',
						'label' => esc_html__( 'Pricing Items', 'bdevs-elementor' ),
						'type' => Controls_Manager::REPEATER,
						'default' => [
							[
								'title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
								'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
							]
						],
						'fields' => [
							[
								'name'        => 'title',
								'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
								'type'        => Controls_Manager::TEXT,
								'dynamic'     => [ 'active' => true ],
								'default'     => esc_html__( 'Perukar HairCut' , 'bdevs-elementor' ),
								'label_block' => true,
							],	
							[
								'name'        => 'price',
								'label'       => esc_html__( 'Price', 'bdevs-elementor' ),
								'type'        => Controls_Manager::TEXT,
								'dynamic'     => [ 'active' => true ],
								'default'     => esc_html__( '$30' , 'bdevs-elementor' ),
								'label_block' => true,
							],	
							[
								'name'        => 'subtitle',
								'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),
								'type'        => Controls_Manager::TEXT,
								'dynamic'     => [ 'active' => true ],
								'default'     => esc_html__( 'Haircut, shampoo, scalp massage, hot towel face treatment.' , 'bdevs-elementor' ),
								'label_block' => true,
							],	
							
							
						],
					]
					
				],
			]
		);
		$this->end_controls_section();
		
		/** 
		*	Layout section 
		**/
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);
		

		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		
		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_price',
			[
				'label'   => esc_html__( 'Show Price', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->add_control(
			'show_subtitle',
			[
				'label'   => esc_html__( 'Show Subtitle', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	
		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		extract($settings);
	?> 
<section class="barber-pricing2 barber-pricing3 section-padding">
    <div class="container">
    	<?php
    	$idd = 0;
    	if ( ! empty( $settings['tabs'] ) && is_array( $settings['tabs'] ) ) :
    		foreach ( $settings['tabs'] as $item ) :
    			$idd++;
    			?>
    	<?php if($idd%2==1) {?>
        <div class="row">
            <!-- img -->
            <div class="col-md-6 p-0 item">
                <div class="img left">
                    <a href="<?php echo wp_kses_post($item['link']); ?>"> <img src="<?php print esc_url($item['image']['url']); ?>" alt="">
                    	<?php if (( '' !== $item['heading'] ) && ( $settings['show_heading'] )) : ?>
                        <div class="centered">
                            <h2><?php echo wp_kses_post($item['heading']); ?></h2>
                        </div>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
            <!-- menu list -->
            <div class="col-md-6 p-0 valign">
                <div class="content barber-pricing">
                	<?php
                	if ( ! empty( $item['tabs2'] ) && is_array( $item['tabs2'] ) ) :
                		foreach ( $item['tabs2'] as $item2 ) :
                			?>
                    <div class="menu-list mb-30">
                        <div class="item">
                            <div class="flex">
                            	<?php if (( '' !== $item2['title'] ) && ( $settings['show_title'] )) : ?>
                                <div class="title"><?php echo wp_kses_post($item2['title']); ?></div>
                                <?php endif; ?>
                                <div class="dots"></div>
                                <?php if (( '' !== $item2['price'] ) && ( $settings['show_price'] )) : ?>
                                <div class="price"><?php echo wp_kses_post($item2['price']); ?></div>
                                <?php endif; ?>
                            </div>
                            <?php if (( '' !== $item2['subtitle'] ) && ( $settings['show_subtitle'] )) : ?>
                            <p><i><?php echo wp_kses_post($item2['subtitle']); ?></i></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>
    	<?php } else { ?>
    	<div class="row">
            <div class="col-md-6 p-0 order2 valign">
                <div class="content barber-pricing">
                	<?php
                	if ( ! empty( $item['tabs2'] ) && is_array( $item['tabs2'] ) ) :
                		foreach ( $item['tabs2'] as $item2 ) :
                			?>
                    <div class="menu-list mb-30">
                        <div class="item">
                            <div class="flex">
                            	<?php if (( '' !== $item2['title'] ) && ( $settings['show_title'] )) : ?>
                                <div class="title"><?php echo wp_kses_post($item2['title']); ?></div>
                                <?php endif; ?>
                                <div class="dots"></div>
                                <?php if (( '' !== $item2['price'] ) && ( $settings['show_price'] )) : ?>
                                <div class="price"><?php echo wp_kses_post($item2['price']); ?></div>
                                <?php endif; ?>
                            </div>
                            <?php if (( '' !== $item2['subtitle'] ) && ( $settings['show_subtitle'] )) : ?>
                            <p><i><?php echo wp_kses_post($item2['subtitle']); ?></i></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
            <div class="col-md-6 p-0 order1 item">
                <div class="img left">
                    <a href="<?php echo wp_kses_post($item['link']); ?>"> <img src="<?php print esc_url($item['image']['url']); ?>" alt="">
                    	<?php if (( '' !== $item['heading'] ) && ( $settings['show_heading'] )) : ?>
                        <div class="centered">
                            <h2><?php echo wp_kses_post($item['heading']); ?></h2>
                        </div>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
    	<?php } ?>
        <?php endforeach; endif; ?>
    </div>
</section>
	<?php
	}

}