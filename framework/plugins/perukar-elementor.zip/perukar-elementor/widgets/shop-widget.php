<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsShop extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-shop';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Shop Widget', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-slideshow';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'shop', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_shop',
			[
				'label' => esc_html__( 'Shop Area', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Post Number', 'bdevs-elementor' ),
				'default'     => __( '9', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'asc',
			]
		);

		$this->add_control(
			'order_by',
			[
				'label'     => esc_html__( 'Order By', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'id'  => esc_html__( 'ID', 'bdevs-elementor' ),
					'title' => esc_html__( 'Title', 'bdevs-elementor' ),
					'date' => esc_html__( 'Date', 'bdevs-elementor' ),
				],
				'default'   => 'date',
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);

		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		$order = $settings['post_order'];
		$post_number = $settings['post_number'];
		$order_by = $settings['order_by'];
		$paged = max(1, get_query_var('paged'), get_query_var('page'));
		?>  

		<div class="shop-area rooms2 section-padding2 shop-elementor">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<div class="row">
							<?php
							$args = array(
								'posts_per_page' => $post_number,
								'post_type'      => 'product',
								'order'          => $order,
								'orderby'        => $order_by,
								'paged'          => $paged,
							);

							$product_query = new \WP_Query($args);

							while ($product_query->have_posts()) : $product_query->the_post();
								$product = wc_get_product(get_the_ID());
								?>
								<div class="col-lg-4 col-md-6 product-item item">
									<div class="position-re o-hidden position-re-order-shop">
										<a href="<?php the_permalink(); ?>">
											<?php the_post_thumbnail(); ?>
										</a>
									</div>
									<span class="category"><span class="price">
										<?php echo $product->get_price_html(); ?></span>
									</span>
									<div class="actions"> 
										<?php $id = $product ? $product->get_id() : get_the_ID();
										echo do_shortcode('[add_to_cart id="' . $id . '"]');?>
										<a class="icon-btn no-scroll" data-toggle="modal" data-target="#exampleModal<?php echo esc_attr($id); ?>"><i class="ti-eye"></i></a>
										<div class="wishlist-icon"><?php echo do_shortcode('[yith_wcwl_add_to_wishlist]'); ?></div>
									</div>
									<div class="con">
										<h4 class="shop"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h4>
										<div class="line"></div>
									</div>
								</div>
								<?php
							endwhile;
							wp_reset_postdata();
							?>
						</div>
						<nav class="woocommerce-pagination">
							<?php
							echo paginate_links(array(
								'base'      => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
								'format'    => '?paged=%#%',
								'current'   => $paged,
								'total'     => $product_query->max_num_pages,
								'prev_text' => __('<i class="ti-angle-left"></i>', 'bdevs-elementor'),
								'next_text' => __('<i class="ti-angle-right"></i>', 'bdevs-elementor'),
								'type'      => 'list',
							));
							?>
						</nav>
						<?php wp_reset_postdata(); ?>
					</div>
				</div>
			</div>
		</div>

		<?php
		$args = array(
			'posts_per_page' => $post_number,
			'post_type'      => 'product',
			'order'          => $order,
			'orderby'        => $order_by,
			'paged'          => $paged,
		);

		$product_query = new \WP_Query($args);

		while ($product_query->have_posts()) : $product_query->the_post();
			$id = get_the_ID();
			?>
			<div class="grid__quick__view__modal modalarea modal fade" id="exampleModal<?php echo esc_attr($id); ?>" tabindex="-1" aria-labelledby="exampleModal" aria-hidden="true">
				<div class="modal-dialog modal__wraper">
					<div class="modal-content">
						<button type="button" class="btn-close" data-dismiss="modal" aria-label="<?php echo esc_attr('Close', 'nextarch'); ?>"></button>

						<div class="modal-body">
							<div class="row">
								<div class="col-md-6">
									<?php 
									$product = wc_get_product($id);
									$attachment_ids = $product->get_gallery_image_ids();
									?>

									<div class="swiper product-main-slider mb-3">
										<div class="swiper-wrapper">
											<div class="swiper-slide">
												<img src="<?php echo wp_get_attachment_url($product->get_image_id()); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" class="img-fluid">
											</div>

											<?php
											if ($attachment_ids) {
												foreach ($attachment_ids as $attachment_id) {
													$image_url = wp_get_attachment_url($attachment_id);
													echo '<div class="swiper-slide">
													<img src="' . esc_url($image_url) . '" alt="' . esc_attr($product->get_name()) . '" class="img-fluid">
													</div>';
												}
											}
											?>
										</div>
										<div class="swiper-pagination"></div>
										<div class="swiper-button-next"></div>
										<div class="swiper-button-prev"></div>
									</div>

									<?php if ($attachment_ids): ?>
										<div class="swiper product-thumbnail-slider mt-2 gallery-thumbs">
											<div class="swiper-wrapper">
												<div class="swiper-slide">
													<img src="<?php echo wp_get_attachment_url($product->get_image_id()); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" class="img-thumbnail">
												</div>
												<?php
												foreach ($attachment_ids as $attachment_id) {
													$thumbnail_url = wp_get_attachment_image_url($attachment_id, 'thumbnail');
													echo '<div class="swiper-slide">
													<img src="' . esc_url($thumbnail_url) . '" alt="' . esc_attr($product->get_name()) . '" class="img-thumbnail">
													</div>';
												}
												?>
											</div>
										</div>
									<?php endif; ?>
								</div>

								<div class="col-md-6 txt-left">
									<h2 class="product_title"><a href="<?php echo esc_url(get_permalink($id)); ?>">
										<?php echo esc_html($product->get_name()); ?>
									</a></h2>
									<div class="price mb-2"><?php echo $product->get_price_html(); ?></div>
									<div class="woocommerce-product-details__short-description"><?php echo wpautop($product->get_short_description()); ?></div>

									<form class="cart" method="post" enctype="multipart/form-data">
										<?php woocommerce_quantity_input(); ?>

										<?php wp_nonce_field('woocommerce-add-to-cart', 'woocommerce-add-to-cart-nonce'); ?>
										<input type="hidden" name="redirect_to_product" value="1" />

										<button type="submit" name="add-to-cart" value="<?php echo esc_attr($id); ?>" 
											class="single_add_to_cart_button button alt">
											<?php echo esc_html($product->single_add_to_cart_text()); ?>
										</button>
									</form>
									<div class="product-wishlist mt-3">
										<?php 
										echo do_shortcode('[yith_wcwl_add_to_wishlist product_id="' . esc_attr($id) . '"]'); 
										?>
									</div>
									<div class="product_meta mt-3">
										<?php
										$product_cats = wp_get_post_terms($id, 'product_cat');
										if (!empty($product_cats) && !is_wp_error($product_cats)) {
											echo '<span class="posted_in">' . __('Category:', 'woocommerce') . ' ';
											$cat_links = array();

											foreach ($product_cats as $cat) {
												$cat_links[] = '<a href="' . esc_url(get_term_link($cat->term_id)) . '" rel="tag">' . esc_html($cat->name) . '</a>';
											}

											echo implode(', ', $cat_links);
											echo '</span>';
										}
										?>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<?php endwhile; ?>

	<?php
	}

}
