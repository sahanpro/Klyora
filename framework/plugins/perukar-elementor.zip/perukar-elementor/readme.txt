=== Bdevs Elementor ===
Contributors: phoenixdigi, namncn
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: slides, carousel, slider
Tested up to: 5.0.3
Requires PHP: 7.0

Create unlimited beautiful sliders with Elementor Page Builder.

== Description ==

Create unlimited beautiful sliders with Elementor Page Builder.

== Installation ==

=== From within WordPress ===

1. Visit 'Plugins > Add New'
2. Search for 'Bdevs Elementor'
3. Activate Bdevs Elementor from your Plugins page.

=== Manually ===

1. Upload the `bdevs-elementor` folder to the `/wp-content/plugins/` directory
2. Activate the Bdevs Elementor plugin through the 'Plugins' menu in WordPress
3. Go to "after activation" below.

== Frequently Asked Questions ==

You'll find answers to many of your questions on (http://bdevs.net/plugins/bdevs-elementor/).


== Changelog ==

= 1.0.0 =
* First release.
