<?php



add_action( 'init', 'register_perukar_Team' );
function register_perukar_Team() {
    
$labels = array( 
'name' => __( 'Team', 'perukar' ),
'singular_name' => __( 'Team', 'perukar' ),
'add_new' => __( 'Add New Team', 'perukar' ),
'add_new_item' => __( 'Add New Team', 'perukar' ),
'edit_item' => __( 'Edit Team', 'perukar' ),
'new_item' => __( 'New Team', 'perukar' ),
'view_item' => __( 'View Team', 'perukar' ),
'search_items' => __( 'Search Team', 'perukar' ),
'not_found' => __( 'No Team found', 'perukar' ),
'not_found_in_trash' => __( 'No Team found in Trash', 'perukar' ),
'parent_item_colon' => __( 'Parent Team:', 'perukar' ),
'menu_name' => __( 'Team', 'perukar' ),
);

$args = array( 
'labels' => $labels,
'hierarchical' => true,
'description' => 'List Team',
'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
'taxonomies' => array( 'Team', 'type1' ),
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'menu_position' => 5,
'menu_icon' => 'dashicons-id-alt', 
'show_in_nav_menus' => true,
'publicly_queryable' => true,
'exclude_from_search' => false,
'has_archive' => true,
'query_var' => true,
'can_export' => true,
'rewrite' => true,
'capability_type' => 'post'
);

register_post_type( 'Team', $args );
}
add_action( 'init', 'create_Type1_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type1_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

$labels = array(
'name' => __( 'Type1', 'perukar' ),
'singular_name' => __( 'Type1', 'perukar' ),
'search_items' =>  __( 'Search Type1','perukar' ),
'all_items' => __( 'All Type1','perukar' ),
    'parent_item' => __( 'Parent Type1','perukar' ),
    'parent_item_colon' => __( 'Parent Type1:','perukar' ),
    'edit_item' => __( 'Edit Type1','perukar' ), 
    'update_item' => __( 'Update Type1','perukar' ),
    'add_new_item' => __( 'Add New Type1','perukar' ),
    'new_item_name' => __( 'New Type1 Name','perukar' ),
    'menu_name' => __( 'Type1','perukar' ),
  );     

// Now register the taxonomy

  register_taxonomy('type1',array('Team'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));


add_action( 'init', 'register_perukar_Services' );
function register_perukar_Services() {
    
$labels = array( 
'name' => __( 'Services', 'perukar' ),
'singular_name' => __( 'Services', 'perukar' ),
'add_new' => __( 'Add New Services', 'perukar' ),
'add_new_item' => __( 'Add New Services', 'perukar' ),
'edit_item' => __( 'Edit Services', 'perukar' ),
'new_item' => __( 'New Services', 'perukar' ),
'view_item' => __( 'View Services', 'perukar' ),
'search_items' => __( 'Search Services', 'perukar' ),
'not_found' => __( 'No Services found', 'perukar' ),
'not_found_in_trash' => __( 'No Services found in Trash', 'perukar' ),
'parent_item_colon' => __( 'Parent Services:', 'perukar' ),
'menu_name' => __( 'Services', 'perukar' ),
);

$args = array( 
'labels' => $labels,
'hierarchical' => true,
'description' => 'List Services',
'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
'taxonomies' => array( 'Services', 'type2' ),
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'menu_position' => 5,
'menu_icon' => 'dashicons-id-alt', 
'show_in_nav_menus' => true,
'publicly_queryable' => true,
'exclude_from_search' => false,
'has_archive' => true,
'query_var' => true,
'can_export' => true,
'rewrite' => true,
'capability_type' => 'post'
);

register_post_type( 'Services', $args );
}
add_action( 'init', 'create_Type2_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

}

?>